# travelntrack
This project called Travel n Track,
uses location features of users device for verification purposes.
I have worked on HTML, CSS, Javascript, Nodejs, MongoDB, ExpressJS, EJS, Bootstrap
in this project to implement features like 
Profile Page, Leaderboard, Realtime Location Coordinates, and User Authentication.
<h1>Live deployed- <a href="http://travelntrack.herokuapp.com/">https://travelntrack.onrender.com/</a></h1>
